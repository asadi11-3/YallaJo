# ContentPlaces Module - Team Task Distribution

> **Module**: ContentPlaces (34 endpoints)
> **Sprint Focus**: Phase 1 MVP
> **Reference Files**: `Agents/ContentPlaces-tasks.md` (full implementation spec), `Agents/guide.md` (code patterns), `Agents/error-log.md` (mistakes to avoid)
> **Business Rules PDF**: Sections 2.1 (Place Management), 1.2-1.5 (Provider/Business Registration), 10 (Interactive Map), 14 (Accessibility)

---

## Team Members

| Name | Level | Assigned Tasks | Endpoint Count |
|------|-------|---------------|----------------|
| **Mahmoud** | Intermediate | Task 1: Place CQRS + Admin Actions | 8 |
| **Mohammad** | Intermediate | Task 2: Business CQRS + State Machine, Task 3: BusinessHours | 11 |
| **Ezz** | Beginner | Task 4: ServiceItem CQRS, Task 7: Geo-Search | 7 |
| **Fadwa** | Beginner | Task 5: BusinessAmenity, Task 6: BusinessStaff, Task 8: Accessibility | 8 |

---

## Before You Start (Everyone Must Read)

1. `Agents/guide.md` - Code patterns bible. Every line you write must match.
2. `Agents/error-log.md` - Mistakes previous agents made. Don't repeat them.
3. `Agents/agent-context.md` - Section "New Entity Checklist" + "Common Mistakes & Fixes"
4. `Agents/ContentPlaces-tasks.md` - YOUR task section has exact code, DTOs, validator rules
5. `Agents/YallaJo Business Rules & Edge Cases.pdf` - Section 2 (Places/Tours) for business rules

### Critical Rules for ALL Tasks

- Use `IContentPlacesUnitOfWork` for saves, never `dbContext.SaveChangesAsync()` directly
- `Guid.CreateVersion7()` in all factory methods (never `Guid.NewGuid()`)
- `DateTime.UtcNow` everywhere (never `DateTime.Now`)
- Pass `CancellationToken ct` through every async method
- Add `ILogger<THandler>` to every handler
- Never return entity objects from endpoints - always map to DTOs
- Run `dotnet build` after your work - must be 0 errors

---

## Mahmoud (Intermediate) - Task 1: Place CQRS + Admin Actions

**8 endpoints | No dependencies - START FIRST**
**Reference**: `ContentPlaces-tasks.md` > Task 1

### Endpoints

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 1 | `GET` | `/api/v1/places` | Anonymous | ListPlaces |
| 2 | `GET` | `/api/v1/places/{id}` | Anonymous | GetPlaceById |
| 3 | `GET` | `/api/v1/places/{slug}` | Anonymous | GetPlaceBySlug |
| 4 | `POST` | `/api/v1/places` | Admin | CreatePlace |
| 5 | `PUT` | `/api/v1/places/{id}` | Admin | UpdatePlace |
| 6 | `DELETE` | `/api/v1/places/{id}` | Admin | DeletePlace |
| 7 | `PATCH` | `/api/v1/places/{id}/feature` | Admin | FeaturePlace |
| 8 | `PATCH` | `/api/v1/places/{id}/verify` | Admin | VerifyPlace |

### Business Rules (from PDF Section 2.1)

- **Admin only**: Only admins can create, edit, or delete places
- **Unique slug**: Slug must be globally unique. Auto-generate from name if not provided (lowercase, hyphens, `^[a-z0-9\-]+$`)
- **Coordinate validation**: Latitude [-90, 90], Longitude [-180, 180] - required fields
- **Cannot delete if has children**: A place cannot be deleted if it has active (non-deleted) tours, businesses, or blogs linked to it
- **Multi-language translations**: Arabic + English minimum. Trigger `EntityTranslationOrchestrator` on create. On update, re-trigger if name/description/address changed
- **Accessibility defaults**: `IsWheelchairAccessible`, `HasAudioGuide`, `HasBrailleSignage` default to `false`
- **Soft delete**: `DeletePlace` sets `IsDeleted = true`, `DeletedAt = DateTime.UtcNow`
- **Pagination**: `ListPlaces` max PageSize = 50. Filters: CategoryId, RatingMin, RatingMax, City, Country, HasActiveTours

### What You Need to Build

1. **Domain**: Add `Create()`, `Update()`, `SoftDelete()`, `SetFeatured()`, `SetVerified()`, `UpdateRating()` to `Place.cs`. Create `PlaceCreatedDomainEvent`, `PlaceUpdatedDomainEvent`. Create `IPlaceRepository`
2. **Application**: 5 command folders (Create, Update, Delete, Feature, Verify) + 3 query folders (List, GetById, GetBySlug) with handlers, validators, DTOs
3. **Infrastructure**: `PlaceRepository`, register in `DependencyInjection.cs`
4. **Contracts**: `PlaceCreatedIntegrationEvent`
5. **Presentation**: 8 endpoints in `ContentPlacesEndpoints.cs`

### Edge Cases to Handle

- Slug collision on create/update: check `ExistsBySlugAsync` / `ExistsBySlugExcludingAsync`
- Delete blocked if active businesses exist (query `PlaceBusiness` junction or `Business` table)
- `GetPlaceBySlug` must return same DTO as `GetPlaceById`
- `ListPlaces` returns `PlaceSummaryDto` (compact), detail endpoints return `PlaceDetailDto` (full)

### Validator Rules (CreatePlaceCommandValidator)

```
Name:        .NotEmpty().MaximumLength(300)
Slug:        .NotEmpty().MaximumLength(300).Matches(@"^[a-z0-9\-]+$")
Lat:         .InclusiveBetween(-90, 90)
Lng:         .InclusiveBetween(-180, 180)
Description: .MaximumLength(4000).When(x => x.Description != null)
Phone:       .MaximumLength(50).When(x => x.Phone != null)
Email:       .EmailAddress().When(x => x.Email != null)
Website:     .MaximumLength(500).When(x => x.Website != null)
PlaceType:   .IsInEnum()
```

---

## Mohammad (Intermediate) - Task 2: Business CQRS + State Machine + Task 3: BusinessHours

**11 endpoints | Depends on: Task 1 (Place must exist for CreateBusiness)**
**Reference**: `ContentPlaces-tasks.md` > Task 2 and Task 3

### Task 2 Endpoints - Business (9 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 9 | `GET` | `/api/v1/places/{id}/businesses` | Anonymous | ListPlaceBusinesses |
| 10 | `GET` | `/api/v1/places/businesses/{id}` | Anonymous | GetBusinessById |
| 11 | `POST` | `/api/v1/places/businesses` | Authenticated | CreateBusiness |
| 12 | `PUT` | `/api/v1/places/businesses/{id}` | Authenticated | UpdateBusiness |
| 13 | `DELETE` | `/api/v1/places/businesses/{id}` | Admin | DeleteBusiness |
| 14 | `POST` | `/api/v1/places/businesses/{id}/resubmit` | Authenticated | ResubmitBusiness |
| 15 | `POST` | `/api/v1/places/businesses/admin/{id}/approve` | Admin | ApproveBusiness |
| 16 | `POST` | `/api/v1/places/businesses/admin/{id}/reject` | Admin | RejectBusiness |
| 17 | `POST` | `/api/v1/places/businesses/admin/{id}/suspend` | Admin | SuspendBusiness |

### Task 3 Endpoints - BusinessHours (2 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 18 | `GET` | `/api/v1/places/businesses/{id}/hours` | Anonymous | GetBusinessHours |
| 19 | `PUT` | `/api/v1/places/businesses/{id}/hours` | Authenticated | SetBusinessHours |

### Business State Machine (CRITICAL - get this right)

```
Pending  --[Admin Approve]--> Approved
Pending  --[Admin Reject]---> Rejected     (requires RejectionReason)
Rejected --[Owner Resubmit]-> Pending      (clears RejectionReason)
Approved --[Admin Suspend]--> Suspended    (requires reason)
Suspended -[Admin Reinstate]-> Approved
```

**Every transition must guard the current state.** If current status doesn't match precondition, return:
`Result.Failure(Error.Conflict("Business.InvalidTransition", "Cannot {action} a business with status {currentStatus}"))`

### Business Rules (from PDF Section 1.2-1.5 + ContentPlaces-tasks.md)

- **CreateBusiness**: Verify PlaceId exists and not deleted. Insert `PlaceBusiness` junction row. Auto-create 7 default `BusinessHours` rows (all days `IsClosed = true`). Status starts as `Pending`
- **UpdateBusiness**: IDOR check - `business.OwnerId == currentUserId || isAdmin`. If PlaceId changed, delete old `PlaceBusiness`, insert new one
- **DeleteBusiness**: Admin only. Soft delete
- **RejectBusiness**: Requires `Reason` string (mandatory). Stores in `RejectionReason`
- **ResubmitBusiness**: Owner only. Guard: current status must be `Rejected`. Clears `RejectionReason`
- **SuspendBusiness**: Admin only. Guard: current status must be `Approved`. Requires `Reason`
- **ListPlaceBusinesses**: Public returns `Status = Approved` only. Admin/Owner sees all statuses

### BusinessHours Rules

- **Batch replace strategy**: Delete all existing rows for BusinessId, then insert new ones
- **Max 2 entries per day** (split shifts allowed, e.g. 09:00-13:00 and 17:00-22:00)
- **Overlap validation**: If same day has 2 entries, `entry2.OpenTime >= entry1.CloseTime`
- **IDOR check**: `business.OwnerId == currentUserId || isAdmin`
- **If `!IsClosed`**: `OpenTime < CloseTime` (unless 24h: both `00:00`)

### What You Need to Build

1. **Domain**: `Business.Create()`, `Update()`, `SoftDelete()`, `Approve()`, `Reject()`, `Resubmit()`, `Suspend()`, `Reinstate()`, `SetVerified()`, `SetFeatured()`, `UpdateRating()`. Domain events: `BusinessCreatedDomainEvent`, `BusinessUpdatedDomainEvent`, `BusinessApprovedDomainEvent`, `BusinessRejectedDomainEvent`. `IBusinessRepository`. Also `BusinessHours.Create()`, `Update()`
2. **Application**: 8 command folders + 2 query folders (Business) + 1 command + 1 query (Hours)
3. **Infrastructure**: `BusinessRepository`, DI registration. `PlaceBusiness` junction managed via DbContext directly
4. **Presentation**: 11 endpoints

### Edge Cases

- Two users register business with same slug: enforce `ExistsBySlugAsync`
- Business resubmit when status is not `Rejected`: return `Conflict`
- SetBusinessHours with overlapping shifts on same day: validator must catch
- CreateBusiness when PlaceId is soft-deleted: return `NotFound`

---

## Ezz (Beginner) - Task 4: ServiceItem CQRS + Task 7: Geo-Search

**7 endpoints | Depends on: Task 2 (Business must exist)**
**Reference**: `ContentPlaces-tasks.md` > Task 4 and Task 7

### Task 4 Endpoints - ServiceItem (5 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 20 | `GET` | `/api/v1/places/businesses/{id}/services` | Anonymous | ListServiceItems |
| 21 | `GET` | `/api/v1/places/businesses/services/{id}` | Anonymous | GetServiceItemById |
| 22 | `POST` | `/api/v1/places/businesses/{id}/services` | Authenticated | CreateServiceItem |
| 23 | `PUT` | `/api/v1/places/businesses/services/{id}` | Authenticated | UpdateServiceItem |
| 24 | `DELETE` | `/api/v1/places/businesses/services/{id}` | Authenticated | DeleteServiceItem |

### Task 7 Endpoints - Geo-Search (2 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 31 | `GET` | `/api/v1/places/nearby` | Anonymous | GetNearbyPlaces |
| 32 | `GET` | `/api/v1/places/map/viewport` | Anonymous | GetMapViewport |

### ServiceItem Business Rules

- **Entity type**: `AuditableEntity` (non-aggregate) - use `EfEntityRepository<ServiceItem, Guid>`
- **IDOR check on ALL writes**: `business.OwnerId == currentUserId || isAdmin`
- **Soft delete**: Sets `IsDeleted = true`, `DeletedAt = DateTime.UtcNow`
- **ListServiceItems**: Public shows `IsAvailable = true` only. Owner/Admin sees all. Sorted by `SortOrder`
- **Price validation**: `Price >= 0`, `DurationMinutes > 0`, `MaxCapacity > 0`
- **Currency**: Always uppercase (`currency.ToUpperInvariant()`)
- **Discount fields**: `ApplyDiscount()` and `RemoveDiscount()` methods exist but are called from Finance module later - just implement the domain methods

### Geo-Search Business Rules (from PDF Section 10)

- **GetNearbyPlaces**: Uses Haversine formula (raw SQL). Returns places within `RadiusKm` sorted by distance. Max radius = 100km. Max 50 results
- **GetMapViewport**: Simple bounding box LINQ filter. Returns lightweight `MapPinDto` for map rendering. Sets `IsClusteringRecommended = true` when count > 50
- **Coordinates**: Only active, non-deleted places with valid coordinates shown. Exclude `(0.0, 0.0)` coordinates (likely data entry error)
- **Map pin data is LIGHTWEIGHT**: Only Id, Name, Lat, Lng, PrimaryImageUrl, AverageRating, TourCount (no full entity)

### What You Need to Build

**ServiceItem (Task 4):**
1. **Domain**: `ServiceItem.Create()`, `Update()`, `SetAvailability()`, `ApplyDiscount()`, `RemoveDiscount()`, `SoftDelete()`. `IServiceItemRepository`
2. **Application**: 3 commands (Create, Update, Delete) + 2 queries (List, GetById) + DTOs (`ServiceItemSummaryDto`, `ServiceItemDetailDto`)
3. **Infrastructure**: `ServiceItemRepository` extending `EfEntityRepository<ServiceItem, Guid>`, DI registration

**Geo-Search (Task 7):**
1. **Application only** - no domain changes. 2 query handlers. `NearbyPlaceSummaryDto`, `MapViewportResponse`, `MapPinDto`
2. Use `dbContext.Places.FromSqlInterpolated(...)` for Haversine, or LINQ for viewport

### Validator Rules

```
-- ServiceItem --
Name:            .NotEmpty().MaximumLength(300)
Price:           .GreaterThanOrEqualTo(0)
DurationMinutes: .GreaterThan(0)
MaxCapacity:     .GreaterThan(0)
Currency:        .NotEmpty().MaximumLength(3)
Category:        .IsInEnum()
BusinessId:      .NotEqual(Guid.Empty)

-- GetNearbyPlaces --
Lat:       .InclusiveBetween(-90, 90)
Lng:       .InclusiveBetween(-180, 180)
RadiusKm:  .InclusiveBetween(0.1, 100)
PageSize:  .InclusiveBetween(1, 50)

-- GetMapViewport --
NorthLat > SouthLat, EastLng > WestLng, all in valid ranges
```

---

## Fadwa (Beginner) - Task 5: BusinessAmenity + Task 6: BusinessStaff + Task 8: Accessibility

**8 endpoints | Depends on: Task 2 (Business must exist) / Task 1 (Place must exist for Task 8)**
**Reference**: `ContentPlaces-tasks.md` > Task 5, Task 6, Task 8

### Task 5 Endpoints - BusinessAmenity (3 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 25 | `GET` | `/api/v1/places/businesses/{id}/amenities` | Anonymous | ListBusinessAmenities |
| 26 | `POST` | `/api/v1/places/businesses/{id}/amenities` | Authenticated | AddBusinessAmenity |
| 27 | `DELETE` | `/api/v1/places/businesses/amenities/{id}` | Authenticated | RemoveBusinessAmenity |

### Task 6 Endpoints - BusinessStaff (3 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 28 | `GET` | `/api/v1/places/businesses/{id}/staff` | Authenticated | ListBusinessStaff |
| 29 | `POST` | `/api/v1/places/businesses/{id}/staff` | Authenticated | AddBusinessStaff |
| 30 | `DELETE` | `/api/v1/places/businesses/staff/{id}` | Authenticated | RemoveBusinessStaff |

### Task 8 Endpoints - AccessibilityFeature (2 endpoints)

| # | Method | Route | Auth | Handler |
|---|--------|-------|------|---------|
| 33 | `GET` | `/api/v1/places/{id}/accessibility` | Anonymous | GetAccessibilityFeatures |
| 34 | `PUT` | `/api/v1/places/{id}/accessibility` | Admin | UpdateAccessibilityFeatures |

### BusinessAmenity Rules

- **Entity type**: `BaseEntity` (non-aggregate) - NO `IsDeleted`, NO `RowVersion`
- **Hard delete**: Use `dbContext.BusinessAmenities.Remove(amenity)` - no soft delete
- **No separate repository**: Managed via `ContentPlacesDbContext` directly
- **IDOR check**: Owner or admin only for add/remove
- **Sorted by `SortOrder`** in list query
- Simple entity: just `Name`, `Icon` (optional), `SortOrder`

### BusinessStaff Rules

- **Entity type**: `AuditableEntity` (non-aggregate) - HAS `IsDeleted`, `RowVersion`
- **Unique constraint**: `(BusinessId, UserId)` filtered where `IsDeleted = 0` - already in EF config
- **Staff list is NOT public**: Owner or admin only
- **AddBusinessStaff**: Check if `UserId` is already active staff: `dbContext.BusinessStaff.AnyAsync(x => x.BusinessId == id && x.UserId == userId && !x.IsDeleted)`
- **RemoveBusinessStaff**: Calls `SoftDelete()`, not hard delete
- **IDOR check**: Owner or admin only

### AccessibilityFeature Rules (from PDF Section 14)

- **Entity type**: `BaseEntity` - NO `IsDeleted`, NO `RowVersion`
- **Hard-replace strategy**: Delete all existing rows for `(EntityType, EntityId)`, insert new set
- **Polymorphic**: `EntityType (byte)` + `EntityId (Guid)` - for now only `EntityType = Place`
- **Feature types**: WheelchairAccessible, RampsAvailable, AccessibleRestrooms, FlatTerrain, SignLanguageGuide, AudioGuide, BrailleSignage
- **Admin only** for updates
- **No separate repository**: Use `ContentPlacesDbContext` directly

### What You Need to Build

**BusinessAmenity (Task 5):**
1. **Domain**: `BusinessAmenity.Create()`, `Update()`
2. **Application**: 1 query (ListBusinessAmenities) + 2 commands (Add, Remove) + `BusinessAmenityDto`
3. No infrastructure repo needed (DbContext direct)

**BusinessStaff (Task 6):**
1. **Domain**: `BusinessStaff.Create()`, `Deactivate()`, `SoftDelete()`
2. **Application**: 1 query (ListBusinessStaff) + 2 commands (Add, Remove) + `BusinessStaffDto`
3. No infrastructure repo needed (DbContext direct)

**AccessibilityFeature (Task 8):**
1. **Domain**: `AccessibilityFeature.Create()`, `Update()`
2. **Application**: 1 query (GetAccessibilityFeatures) + 1 command (UpdateAccessibilityFeatures) + DTOs
3. No infrastructure repo needed (DbContext direct)

### Validator Rules

```
-- BusinessAmenity --
Name:       .NotEmpty().MaximumLength(200)
SortOrder:  .GreaterThanOrEqualTo(0)
BusinessId: .NotEqual(Guid.Empty)

-- BusinessStaff --
BusinessId: .NotEqual(Guid.Empty)
UserId:     .NotEqual(Guid.Empty)
Role:       .IsInEnum()

-- AccessibilityFeature --
PlaceId:     .NotEqual(Guid.Empty)
Features:    .NotEmpty()
Per item:    FeatureType .IsInEnum(), Name .NotEmpty().MaximumLength(200)
```

---

## Dependency Graph & Suggested Order

```
Mahmoud (Task 1: Place)          <-- START FIRST (no dependencies)
    |
    v
Mohammad (Task 2: Business)      <-- Needs PlaceId from Task 1
Mohammad (Task 3: Hours)         <-- Needs BusinessId from Task 2
    |
    v
Ezz (Task 4: ServiceItem)       <-- Needs BusinessId from Task 2
Fadwa (Task 5: Amenity)          <-- Needs BusinessId from Task 2
Fadwa (Task 6: Staff)            <-- Needs BusinessId from Task 2
    |
    v
Ezz (Task 7: Geo-Search)        <-- Needs Places from Task 1
Fadwa (Task 8: Accessibility)    <-- Needs PlaceId from Task 1
```

**Practical timeline:**
- **Day 1**: Mahmoud starts Task 1. Everyone else reads guide.md, error-log.md, and their task sections
- **Day 2-3**: Mahmoud continues Task 1. Mohammad can start Business domain/application layer (compile-time dependency only needs IPlaceRepository interface, not implementation)
- **Day 3+**: Once Task 1 merges, everyone else can start their tasks in parallel
- Ezz and Fadwa's tasks are independent of each other - can run in parallel

---

## Checklist Before Submitting PR

Every team member must verify before marking done:

- [ ] `dotnet build` passes with 0 errors
- [ ] All handlers have `ILogger<THandler>` injected
- [ ] All async methods accept and pass `CancellationToken ct`
- [ ] All new repos/services registered in `DependencyInjection.cs`
- [ ] All DTOs use `record` type (not class)
- [ ] All endpoints have `.WithName()`, `.WithSummary()`, `.Produces<T>()`
- [ ] All POST/PUT endpoints have `.ProducesValidationProblem()`
- [ ] All GET/{id}, PUT, DELETE endpoints have `.ProducesProblem(404)`
- [ ] Every endpoint has either `.RequireAuthorization()` or `.AllowAnonymous()`
- [ ] `Guid.CreateVersion7()` used (never `Guid.NewGuid()`)
- [ ] `DateTime.UtcNow` used (never `DateTime.Now`)
- [ ] No `as any` / `@ts-ignore` equivalent in C# (no type suppression)
- [ ] Error codes follow `{Entity}.{Reason}` convention (e.g., `Place.NotFound`, `Business.InvalidTransition`)

---

## Domain Events & Integration Events — Complete Reference

### Convention (match existing codebase exactly)

```csharp
// Domain events — raised inside entity methods, dispatched by UoW before SaveChanges
// Location: ContentPlaces.Domain/Events/
// Base class: DomainEventBase (from YallaJo.SharedKernel.Domain.Event)
// Pattern: sealed record, suffix "DomainEvent"
public sealed record PlaceCreatedDomainEvent(
    Guid PlaceId,
    string Name,
    string Slug) : DomainEventBase;

// Integration events — cross-module communication via outbox/inbox
// Location: ContentPlaces.Contracts/IntegrationEvents/
// Base class: IntegrationEventBase (from YallaJo.SharedKernel.Domain.Event)
// Pattern: sealed record, suffix "IntegrationEvent"
public sealed record PlaceCreatedIntegrationEvent(
    Guid PlaceId,
    string Name,
    string Slug) : IntegrationEventBase;
```

### Important Rules

1. **Domain events ONLY dispatch from `IAggregateRoot` entities** (Place, Business). Non-aggregates (ServiceItem, BusinessStaff, BusinessAmenity, BusinessHours, AccessibilityFeature) CANNOT raise domain events — they are silently ignored by `UnitOfWork.SaveChangesAsync()`. See Gotcha #1
2. **NEVER call `SaveChangesAsync` inside a domain event handler** — UoW dispatches events BEFORE SaveChanges. Handler changes are persisted atomically. See Gotcha #2
3. **Domain event handlers** go in `ContentPlaces.Application/EventHandlers/`
4. **Integration event handlers** that CONSUME events from other modules go in `ContentPlaces.Infrastructure/EventHandlers/` (already exists: `LanguageActivatedIntegrationEventHandler`)
5. **Integration events this module PUBLISHES** go in `ContentPlaces.Contracts/IntegrationEvents/`
6. **Raise domain events inside the entity's factory/business method**, not in the handler

---

### Mahmoud — Place Events (Task 1)

**Domain Events** (`ContentPlaces.Domain/Events/`):

| Event | Record Definition | Raised In |
|-------|-------------------|-----------|
| `PlaceCreatedDomainEvent` | `(Guid PlaceId, string Name, string Slug)` | `Place.Create()` |
| `PlaceUpdatedDomainEvent` | `(Guid PlaceId, string Name, string? Description, string? Address)` | `Place.Update()` |

```csharp
// PlaceCreatedDomainEvent.cs
using YallaJo.SharedKernel.Domain.Event;
namespace ContentPlaces.Domain.Events;

public sealed record PlaceCreatedDomainEvent(
    Guid PlaceId,
    string Name,
    string Slug) : DomainEventBase;

// PlaceUpdatedDomainEvent.cs
public sealed record PlaceUpdatedDomainEvent(
    Guid PlaceId,
    string Name,
    string? Description,
    string? Address) : DomainEventBase;
```

**Domain Event Handlers** (`ContentPlaces.Application/EventHandlers/`):

| Handler | What It Does |
|---------|-------------|
| `PlaceCreatedDomainEventHandler` | Triggers `EntityTranslationOrchestrator` for auto-translation. Publishes `PlaceCreatedIntegrationEvent` to outbox |
| `PlaceUpdatedDomainEventHandler` | Re-triggers translation if Name/Description/Address changed. Publishes `PlaceUpdatedIntegrationEvent` to outbox |

**Integration Events** (`ContentPlaces.Contracts/IntegrationEvents/`):

| Event | Record Definition | Consumed By |
|-------|-------------------|-------------|
| `PlaceCreatedIntegrationEvent` | `(Guid PlaceId, string Name, string Slug)` | ContentSeo (sitemap), Analytics (popularity init) |
| `PlaceUpdatedIntegrationEvent` | `(Guid PlaceId, string Name, string? Description, string? Address)` | ContentSeo (slug redirect if changed) |
| `PlaceDeletedIntegrationEvent` | `(Guid PlaceId)` | Booking, Social (cleanup), ContentTours |

```csharp
// ContentPlaces.Contracts/IntegrationEvents/
using YallaJo.SharedKernel.Domain.Event;
namespace ContentPlaces.Contracts.IntegrationEvents;

public sealed record PlaceCreatedIntegrationEvent(
    Guid PlaceId, string Name, string Slug) : IntegrationEventBase;

public sealed record PlaceUpdatedIntegrationEvent(
    Guid PlaceId, string Name, string? Description, string? Address) : IntegrationEventBase;

public sealed record PlaceDeletedIntegrationEvent(
    Guid PlaceId) : IntegrationEventBase;
```

---

### Mohammad — Business Events (Task 2)

**Domain Events** (`ContentPlaces.Domain/Events/`):

| Event | Record Definition | Raised In |
|-------|-------------------|-----------|
| `BusinessCreatedDomainEvent` | `(Guid BusinessId, string Name, string Slug, Guid OwnerId, Guid? PlaceId)` | `Business.Create()` |
| `BusinessUpdatedDomainEvent` | `(Guid BusinessId, string Name, string? Description, string? Address)` | `Business.Update()` |
| `BusinessApprovedDomainEvent` | `(Guid BusinessId, Guid ReviewedByUserId)` | `Business.Approve()` |
| `BusinessRejectedDomainEvent` | `(Guid BusinessId, string Reason)` | `Business.Reject()` |
| `BusinessSuspendedDomainEvent` | `(Guid BusinessId, string Reason)` | `Business.Suspend()` |
| `BusinessReinstatedDomainEvent` | `(Guid BusinessId)` | `Business.Reinstate()` |

```csharp
// ContentPlaces.Domain/Events/
using YallaJo.SharedKernel.Domain.Event;
namespace ContentPlaces.Domain.Events;

public sealed record BusinessCreatedDomainEvent(
    Guid BusinessId, string Name, string Slug, Guid OwnerId, Guid? PlaceId) : DomainEventBase;

public sealed record BusinessUpdatedDomainEvent(
    Guid BusinessId, string Name, string? Description, string? Address) : DomainEventBase;

public sealed record BusinessApprovedDomainEvent(
    Guid BusinessId, Guid ReviewedByUserId) : DomainEventBase;

public sealed record BusinessRejectedDomainEvent(
    Guid BusinessId, string Reason) : DomainEventBase;

public sealed record BusinessSuspendedDomainEvent(
    Guid BusinessId, string Reason) : DomainEventBase;

public sealed record BusinessReinstatedDomainEvent(
    Guid BusinessId) : DomainEventBase;
```

**Domain Event Handlers**:

| Handler | What It Does |
|---------|-------------|
| `BusinessCreatedDomainEventHandler` | Triggers translation. Publishes `BusinessCreatedIntegrationEvent` to outbox |
| `BusinessApprovedDomainEventHandler` | Publishes `BusinessApprovedIntegrationEvent` (notify owner) |
| `BusinessRejectedDomainEventHandler` | Publishes `BusinessRejectedIntegrationEvent` (notify owner with reason) |
| `BusinessSuspendedDomainEventHandler` | Publishes `BusinessSuspendedIntegrationEvent` (hide tours, notify users) |

**Integration Events** (`ContentPlaces.Contracts/IntegrationEvents/`):

| Event | Record Definition | Consumed By |
|-------|-------------------|-------------|
| `BusinessCreatedIntegrationEvent` | `(Guid BusinessId, string Name, string Slug, Guid OwnerId, Guid? PlaceId)` | Messaging (admin notification) |
| `BusinessApprovedIntegrationEvent` | `(Guid BusinessId, Guid OwnerId)` | Messaging (notify owner) |
| `BusinessRejectedIntegrationEvent` | `(Guid BusinessId, Guid OwnerId, string Reason)` | Messaging (notify owner) |
| `BusinessSuspendedIntegrationEvent` | `(Guid BusinessId, Guid OwnerId, string Reason)` | Messaging, Booking (block new bookings) |
| `BusinessReinstatedIntegrationEvent` | `(Guid BusinessId, Guid OwnerId)` | Messaging (notify owner) |

```csharp
// ContentPlaces.Contracts/IntegrationEvents/
using YallaJo.SharedKernel.Domain.Event;
namespace ContentPlaces.Contracts.IntegrationEvents;

public sealed record BusinessCreatedIntegrationEvent(
    Guid BusinessId, string Name, string Slug, Guid OwnerId, Guid? PlaceId) : IntegrationEventBase;

public sealed record BusinessApprovedIntegrationEvent(
    Guid BusinessId, Guid OwnerId) : IntegrationEventBase;

public sealed record BusinessRejectedIntegrationEvent(
    Guid BusinessId, Guid OwnerId, string Reason) : IntegrationEventBase;

public sealed record BusinessSuspendedIntegrationEvent(
    Guid BusinessId, Guid OwnerId, string Reason) : IntegrationEventBase;

public sealed record BusinessReinstatedIntegrationEvent(
    Guid BusinessId, Guid OwnerId) : IntegrationEventBase;
```

### Mohammad — BusinessHours (Task 3): NO Events

`BusinessHours` is `BaseEntity` (not aggregate root). Domain events raised here would be silently ignored. No cross-module impact, no integration events needed.

---

### Ezz — ServiceItem (Task 4): NO Domain Events, HAS Integration Events

`ServiceItem` is `AuditableEntity` (non-aggregate). Cannot raise domain events. Publish integration events **directly from command handlers** via outbox:

| Event | Record Definition | Published By |
|-------|-------------------|-------------|
| `ServiceItemCreatedIntegrationEvent` | `(Guid ServiceItemId, Guid BusinessId, string Name, decimal Price, string Currency)` | `CreateServiceItemCommandHandler` |
| `ServiceItemDeletedIntegrationEvent` | `(Guid ServiceItemId, Guid BusinessId)` | `DeleteServiceItemCommandHandler` |

```csharp
// ContentPlaces.Contracts/IntegrationEvents/
public sealed record ServiceItemCreatedIntegrationEvent(
    Guid ServiceItemId, Guid BusinessId, string Name, decimal Price, string Currency) : IntegrationEventBase;

public sealed record ServiceItemDeletedIntegrationEvent(
    Guid ServiceItemId, Guid BusinessId) : IntegrationEventBase;
```

### Ezz — Geo-Search (Task 7): NO Events (read-only queries)

---

### Fadwa — BusinessAmenity (Task 5): NO Events

`BaseEntity`, non-aggregate, simple CRUD, no cross-module impact.

### Fadwa — BusinessStaff (Task 6): NO Domain Events, HAS Integration Events

`AuditableEntity` (non-aggregate). Publish directly from handlers:

| Event | Record Definition | Published By |
|-------|-------------------|-------------|
| `BusinessStaffAddedIntegrationEvent` | `(Guid BusinessStaffId, Guid BusinessId, Guid UserId, string Role)` | `AddBusinessStaffCommandHandler` |
| `BusinessStaffRemovedIntegrationEvent` | `(Guid BusinessStaffId, Guid BusinessId, Guid UserId)` | `RemoveBusinessStaffCommandHandler` |

```csharp
// ContentPlaces.Contracts/IntegrationEvents/
public sealed record BusinessStaffAddedIntegrationEvent(
    Guid BusinessStaffId, Guid BusinessId, Guid UserId, string Role) : IntegrationEventBase;

public sealed record BusinessStaffRemovedIntegrationEvent(
    Guid BusinessStaffId, Guid BusinessId, Guid UserId) : IntegrationEventBase;
```

### Fadwa — AccessibilityFeature (Task 8): NO Events

`BaseEntity`, admin-only batch replace, no cross-module impact.

---

### Inbound Integration Events (pre-existing, no work needed)

| Event | Source | Handler | What It Does |
|-------|--------|---------|-------------|
| `LanguageActivatedIntegrationEvent` | ContentCore | `LanguageActivatedIntegrationEventHandler` | Backfills Place + Business translations when a new language is activated |

---

### Event Flow Diagram

```
Place.Create()  --> PlaceCreatedDomainEvent
                     --> Handler --> translation + PlaceCreatedIntegrationEvent --> [Seo, Analytics]

Place.Update()  --> PlaceUpdatedDomainEvent
                     --> Handler --> re-translate + PlaceUpdatedIntegrationEvent --> [Seo]

DeletePlaceCmd  --> (handler publishes) --> PlaceDeletedIntegrationEvent --> [Booking, Social]

Business.Create()  --> BusinessCreatedDomainEvent
                        --> Handler --> translation + BusinessCreatedIntegrationEvent --> [Messaging]

Business.Approve() --> BusinessApprovedDomainEvent
                        --> Handler --> BusinessApprovedIntegrationEvent --> [Messaging]

Business.Reject()  --> BusinessRejectedDomainEvent
                        --> Handler --> BusinessRejectedIntegrationEvent --> [Messaging]

Business.Suspend() --> BusinessSuspendedDomainEvent
                        --> Handler --> BusinessSuspendedIntegrationEvent --> [Messaging, Booking]

Business.Reinstate()--> BusinessReinstatedDomainEvent
                        --> Handler --> BusinessReinstatedIntegrationEvent --> [Messaging]

CreateServiceItemCmd  --> (handler) --> ServiceItemCreatedIntegrationEvent
DeleteServiceItemCmd  --> (handler) --> ServiceItemDeletedIntegrationEvent

AddBusinessStaffCmd   --> (handler) --> BusinessStaffAddedIntegrationEvent --> [Messaging]
RemoveBusinessStaffCmd--> (handler) --> BusinessStaffRemovedIntegrationEvent --> [Messaging]

INBOUND: ContentCore --> LanguageActivatedIntegrationEvent --> backfill translations
```

### Summary Count

| Owner | Domain Events | Integration Events (Out) | Event Handlers |
|-------|--------------|--------------------------|----------------|
| **Mahmoud** | 2 | 3 | 2 domain event handlers |
| **Mohammad** | 6 | 5 | 4 domain event handlers |
| **Ezz** | 0 | 2 | 0 |
| **Fadwa** | 0 | 2 | 0 |
| **Total** | **8** | **12** | **6 + 1 pre-existing** |
