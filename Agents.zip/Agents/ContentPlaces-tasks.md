# ContentPlaces Module — Full Implementation Plan

> **Last Updated**: 2026-03-17
> **Build State**: ✅ 0 errors, 0 warnings
> **Total Endpoints**: 34 across 8 tasks
> **Phases Covered**: Phase 1 (MVP), Phase 2 (Discovery), Phase 3 (Growth)

---

## Table of Contents

- [Module State](#module-state)
- [Schema Conflict Resolution](#schema-conflict-resolution)
- [Pre-existing Infrastructure](#pre-existing-infrastructure)
- [Entity Reference](#entity-reference)
- [Task 1 — Place CQRS + Admin Actions](#task-1--place-cqrs--admin-actions)
- [Task 2 — Business CQRS + Full State Machine](#task-2--business-cqrs--full-state-machine)
- [Task 3 — BusinessHours Batch Upsert](#task-3--businesshours-batch-upsert)
- [Task 4 — ServiceItem Full CQRS](#task-4--serviceitem-full-cqrs)
- [Task 5 — BusinessAmenity Management](#task-5--businessamenity-management)
- [Task 6 — BusinessStaff Management](#task-6--businessstaff-management)
- [Task 7 — Place Geo-Search](#task-7--place-geo-search)
- [Task 8 — AccessibilityFeature](#task-8--accessibilityfeature)
- [WBS Plan](#wbs-plan)
- [Endpoint Summary](#endpoint-summary)
- [Critical Rules for This Module](#critical-rules-for-this-module)

---

## Module State

| Layer | Status | Notes |
|---|---|---|
| Domain — Entities | ✅ Properties only | All 10 entities exist. No factory methods, no business methods, no domain events. |
| Domain — Repository Interfaces | ❌ None | Must be created in each task. |
| Application — Commands/Queries | ❌ Empty | Only `IContentPlacesUnitOfWork`, `IContentPlacesInboxStore`, and `DependencyInjection.cs` exist. |
| Infrastructure — EF Configs | ✅ Complete | All 10 entity configurations exist and are correct. |
| Infrastructure — DbContext | ✅ Complete | All `DbSet<T>` registered. Schema `content_places`. |
| Infrastructure — Migrations | ✅ Up to date | Latest: `UpdateBusinessHoursAllowSplitShifts` (2026-03-17). |
| Infrastructure — DI | ⚠️ Partial | DbContext, UoW, InboxStore, OutboxProcessor registered. **Repositories are NOT registered** — add each one in its task. |
| Infrastructure — Event Handlers | ✅ Exists | `LanguageActivatedIntegrationEventHandler` — backfills Place and Business translations when a new language is activated. |
| Presentation | ❌ Empty | `ContentPlacesEndpoints.cs` returns empty. |

---

## Schema Conflict Resolution

**Problem**: `BusinessHoursConfiguration` had a unique index on `(BusinessId, DayOfWeek)`, which enforced only one row per day. `YallaJo.md` specifies split-shift support (two entries per day, e.g. 09:00–13:00 and 17:00–22:00).

**Resolution applied (2026-03-17)**:
1. Removed `HasIndex(x => new { x.BusinessId, x.DayOfWeek }).IsUnique()` from `BusinessHoursConfiguration.cs`
2. Replaced with `HasIndex(x => x.BusinessId)` — regular FK index only
3. Migration `UpdateBusinessHoursAllowSplitShifts` generated and verified
4. **Overlap validation is now enforced at the application layer** in `SetBusinessHoursCommandValidator` and `SetBusinessHoursCommandHandler`

**Design-time factory added**: `ContentPlacesDbContextFactory.cs` in `ContentPlaces.Infrastructure/Persistence/` — required for `dotnet ef migrations` to work.

**Pre-existing ContentCore build errors fixed**:
- `ReorderCategoriesCommand.cs` was truncated — restored with correct record definition
- `ReorderCategoriesCommandHandler.cs` was truncated — restored using `category.SetSortOrder()` and `GetAllAsync(filter: c => ids.Contains(c.Id))`

---

## Pre-existing Infrastructure

Do **not** recreate any of the following — they exist and work:

| File | Location | Notes |
|---|---|---|
| `ContentPlacesDbContext` | `Infrastructure/Persistence/` | All `DbSet<T>` present |
| `ContentPlacesUnitOfWork` | `Infrastructure/Persistence/` | `SaveChangesAsync` only |
| `IContentPlacesUnitOfWork` | `Application/Interfaces/` | Inject this in all handlers |
| `ContentPlacesInboxStore` | `Infrastructure/Persistence/` | Idempotency for integration events |
| `IContentPlacesInboxStore` | `Application/Interfaces/` | Inject this in integration event handlers |
| `LanguageActivatedIntegrationEventHandler` | `Infrastructure/EventHandlers/` | Handles `LanguageActivatedIntegrationEvent` for both Places and Businesses |
| `PlaceTranslation.Create(...)` | `Domain/Entities/` | Factory method exists — use it directly |
| `BusinessTranslation.Create(...)` | `Domain/Entities/` | Factory method exists — use it directly |
| All EF Configurations | `Infrastructure/Persistence/Configurations/` | Complete and correct — do NOT modify |
| All Migrations | `Infrastructure/Migrations/` | Do NOT re-run existing migrations |
| `DependencyInjection.cs` (Application) | `Application/` | MediatR + FluentValidation registered |
| `DependencyInjection.cs` (Infrastructure) | `Infrastructure/` | Add repository registrations here |

---

## Entity Reference

| Entity | Base Class | Soft Delete | Repo Pattern | Notes |
|---|---|---|---|---|
| `Place` | `AuditableEntity + IAggregateRoot` | ✅ `IsDeleted` | `EfRepository<Place>` | Main aggregate. Has `RowVersion`. |
| `PlaceTranslation` | `BaseEntity` | Via `Place.IsDeleted` query filter | DbContext direct | Factory `Create()` exists. |
| `Business` | `AuditableEntity + IAggregateRoot` | ✅ `IsDeleted` | `EfRepository<Business>` | State machine. Has `RowVersion`. |
| `BusinessTranslation` | `BaseEntity` | Via `Business.IsDeleted` query filter | DbContext direct | Factory `Create()` exists. |
| `BusinessHours` | `BaseEntity` | Via `Business.IsDeleted` query filter | DbContext direct | No soft-delete. Max 2 entries/day. |
| `ServiceItem` | `AuditableEntity` (non-aggregate) | ✅ `IsDeleted` | `EfEntityRepository<ServiceItem, Guid>` | Has `RowVersion`. Discount fields included. |
| `BusinessStaff` | `AuditableEntity` (non-aggregate) | ✅ `IsDeleted` | DbContext direct | Unique index on `(BusinessId, UserId)` where `IsDeleted = 0`. |
| `BusinessAmenity` | `BaseEntity` (non-aggregate) | Via `Business.IsDeleted` query filter | DbContext direct | Hard delete. |
| `PlaceBusiness` | Plain class (junction) | N/A | DbContext direct | Composite PK `(PlaceId, BusinessId)`. |
| `AccessibilityFeature` | `BaseEntity` (non-aggregate) | ❌ None | DbContext direct | Hard delete. Polymorphic `(EntityType, EntityId)`. |

---

## Task 1 — Place CQRS + Admin Actions

**Phase**: 1 — MVP
**Endpoints**: 8
**Depends on**: Nothing (first task)

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/Place.cs`

Add to the entity:

```csharp
// Factory
public static Place Create(
    string name, string slug, PlaceType placeType,
    Location location, string? description,
    Guid createdByUserId,
    string? address = null, string? city = null, string? country = null,
    string? postalCode = null, string? phone = null,
    string? email = null, string? website = null,
    string? metaTitle = null, string? metaDescription = null)
{
    ArgumentException.ThrowIfNullOrWhiteSpace(name);
    ArgumentException.ThrowIfNullOrWhiteSpace(slug);
    if (createdByUserId == Guid.Empty)
        throw new ArgumentException("CreatedByUserId is required.", nameof(createdByUserId));

    var place = new Place
    {
        Id = Guid.CreateVersion7(),
        Name = name.Trim(),
        Slug = slug.Trim().ToLowerInvariant(),
        PlaceType = placeType,
        Location = location,
        Description = description?.Trim(),
        Address = address?.Trim(),
        City = city?.Trim(),
        Country = country?.Trim(),
        PostalCode = postalCode?.Trim(),
        Phone = phone?.Trim(),
        Email = email?.Trim(),
        Website = website?.Trim(),
        MetaTitle = metaTitle?.Trim(),
        MetaDescription = metaDescription?.Trim(),
        CreatedByUserId = createdByUserId,
        AverageRating = 0m,
        ReviewCount = 0
    };

    place.AddDomainEvent(new PlaceCreatedDomainEvent(place.Id, place.Name, place.Slug));
    return place;
}

// Business methods
public void Update(string name, string slug, PlaceType placeType,
    Location location, string? description,
    string? address, string? city, string? country, string? postalCode,
    string? phone, string? email, string? website,
    string? metaTitle, string? metaDescription)
{
    ArgumentException.ThrowIfNullOrWhiteSpace(name);
    ArgumentException.ThrowIfNullOrWhiteSpace(slug);
    Name = name.Trim();
    Slug = slug.Trim().ToLowerInvariant();
    PlaceType = placeType;
    Location = location;
    Description = description?.Trim();
    Address = address?.Trim();
    City = city?.Trim();
    Country = country?.Trim();
    PostalCode = postalCode?.Trim();
    Phone = phone?.Trim();
    Email = email?.Trim();
    Website = website?.Trim();
    MetaTitle = metaTitle?.Trim();
    MetaDescription = metaDescription?.Trim();
    MarkUpdated();
    AddDomainEvent(new PlaceUpdatedDomainEvent(Id, Name, Description, Address));
}

public void SoftDelete()
{
    IsDeleted = true;
    DeletedAt = DateTime.UtcNow;
    MarkUpdated();
}

public void SetFeatured(bool isFeatured)
{
    IsFeatured = isFeatured;
    MarkUpdated();
}

public void SetVerified(bool isVerified)
{
    IsVerified = isVerified;
    MarkUpdated();
}

public void UpdateRating(decimal averageRating, int reviewCount)
{
    AverageRating = averageRating;
    ReviewCount = reviewCount;
    MarkUpdated();
}
```

### Domain Events

Create `ContentPlaces.Domain/Events/`:
- `PlaceCreatedDomainEvent.cs` — `record(Guid PlaceId, string Name, string Slug)`
- `PlaceUpdatedDomainEvent.cs` — `record(Guid PlaceId, string Name, string? Description, string? Address)`

### Repository Interface

Create `ContentPlaces.Domain/Repositories/IPlaceRepository.cs`:

```csharp
public interface IPlaceRepository : IRepository<Place>
{
    Task<bool> ExistsBySlugAsync(string slug, CancellationToken ct = default);
    Task<bool> ExistsBySlugExcludingAsync(string slug, Guid excludeId, CancellationToken ct = default);
    Task<Place?> GetBySlugAsync(string slug, CancellationToken ct = default);
    Task<Place?> GetByIdWithTranslationsAsync(Guid id, CancellationToken ct = default);
    Task<List<Place>> GetAllForTranslationAsync(CancellationToken ct = default);
}
```

### Application Layer

**Commands** (`ContentPlaces.Application/Commands/Place/`):

| Folder | Files | Notes |
|---|---|---|
| `CreatePlace/` | `CreatePlaceCommand.cs`, `CreatePlaceCommandHandler.cs`, `CreatePlaceCommandValidator.cs` | Slug uniqueness; trigger `EntityTranslationOrchestrator`; publish `PlaceCreatedIntegrationEvent` to outbox |
| `UpdatePlace/` | `UpdatePlaceCommand.cs`, `UpdatePlaceCommandHandler.cs`, `UpdatePlaceCommandValidator.cs` | Slug uniqueness excluding self; trigger translation if name/description/address changed |
| `DeletePlace/` | `DeletePlaceCommand.cs`, `DeletePlaceCommandHandler.cs` | Admin only; soft delete |
| `FeaturePlace/` | `FeaturePlaceCommand.cs`, `FeaturePlaceCommandHandler.cs` | Admin only; `SetFeatured(bool)` |
| `VerifyPlace/` | `VerifyPlaceCommand.cs`, `VerifyPlaceCommandHandler.cs` | Admin only; `SetVerified(bool)` |

**Queries** (`ContentPlaces.Application/Queries/Place/`):

| Folder | DTO | Notes |
|---|---|---|
| `ListPlaces/` | `PlaceSummaryDto` | Id, Name, Slug, PlaceType, Lat, Lng, City, Country, AverageRating, ReviewCount, IsFeatured, IsVerified, PrimaryImageUrl, TourCount. Filters: CategoryId (via EntityCategory junction), RatingMin, RatingMax, HasActiveTours, CityFilter, CountryFilter. Sort: name/rating/popularity. Pagination max 50. Accept-Language driven. |
| `GetPlaceById/` | `PlaceDetailDto` | All fields + Translations (filtered by Accept-Language) + BusinessCount + Tags |
| `GetPlaceBySlug/` | `PlaceDetailDto` | Same as GetPlaceById |

**DTOs**:

```csharp
// PlaceSummaryDto
public record PlaceSummaryDto(
    Guid Id, string Name, string Slug, string PlaceType,
    double Lat, double Lng, string? City, string? Country,
    decimal AverageRating, int ReviewCount,
    bool IsFeatured, bool IsVerified,
    string? PrimaryImageUrl, int TourCount);

// PlaceDetailDto
public record PlaceDetailDto(
    Guid Id, string Name, string Slug, string PlaceType,
    double Lat, double Lng, string? Address, string? City, string? Country,
    string? PostalCode, string? Phone, string? Email, string? Website,
    string? Description, decimal AverageRating, int ReviewCount,
    bool IsFeatured, bool IsVerified,
    bool IsWheelchairAccessible, bool HasAudioGuide, bool HasBrailleSignage,
    string? MetaTitle, string? MetaDescription,
    int BusinessCount, int TourCount,
    IReadOnlyList<PlaceTranslationDto> Translations,
    DateTime CreatedAt, DateTime? UpdatedAt);

public record PlaceTranslationDto(string LanguageCode, string Name, string? Description, string? Address);
```

### Infrastructure

- `ContentPlaces.Infrastructure/Repositories/PlaceRepository.cs`
- Register in `DependencyInjection.cs`: `services.AddScoped<IPlaceRepository, PlaceRepository>();`

### Presentation (8 endpoints)

```
GET    /api/places                →  ListPlaces          .AllowAnonymous()
GET    /api/places/{id:guid}      →  GetPlaceById        .AllowAnonymous()
GET    /api/places/{slug}         →  GetPlaceBySlug      .AllowAnonymous()
POST   /api/places                →  CreatePlace         .RequireAuthorization("Admin")
PUT    /api/places/{id:guid}      →  UpdatePlace         .RequireAuthorization("Admin")
DELETE /api/places/{id:guid}      →  DeletePlace         .RequireAuthorization("Admin")
PATCH  /api/places/{id:guid}/feature  →  FeaturePlace    .RequireAuthorization("Admin")
PATCH  /api/places/{id:guid}/verify   →  VerifyPlace     .RequireAuthorization("Admin")
```

### Integration Events

Create `ContentPlaces.Contracts/IntegrationEvents/PlaceCreatedIntegrationEvent.cs`:
```csharp
public record PlaceCreatedIntegrationEvent(Guid PlaceId, string Name, string Slug) : IntegrationEvent;
```

### Validator Rules

`CreatePlaceCommandValidator`:
- `Name`: `.NotEmpty().MaximumLength(300)`
- `Slug`: `.NotEmpty().MaximumLength(300).Matches(@"^[a-z0-9\-]+$")`
- `Lat`: `.InclusiveBetween(-90, 90)`
- `Lng`: `.InclusiveBetween(-180, 180)`
- `Description`: `.MaximumLength(4000).When(x => x.Description != null)`
- `Phone`: `.MaximumLength(50).When(x => x.Phone != null)`
- `Email`: `.EmailAddress().When(x => x.Email != null)`
- `Website`: `.MaximumLength(500).When(x => x.Website != null)`
- `PlaceType`: `.IsInEnum()`
- `CreatedByUserId`: `.NotEqual(Guid.Empty)`
- `PageSize` (ListPlaces): `.InclusiveBetween(1, 50)`

---

## Task 2 — Business CQRS + Full State Machine

**Phase**: 1 — MVP
**Endpoints**: 9
**Depends on**: Task 1 (CreateBusiness verifies PlaceId exists via IPlaceRepository)

### State Machine

```
Pending  ──[Admin Approve]──►  Approved
Pending  ──[Admin Reject]───►  Rejected  (requires RejectionReason)
Rejected ──[Owner Resubmit]──► Pending   (clears RejectionReason)
Approved ──[Admin Suspend]───► Suspended (requires reason)
Suspended ──[Admin Reinstate]► Approved
```

Guard on all transitions: return `Result.Failure(Error.Conflict("Business.InvalidTransition", "..."))` if current status doesn't match precondition.

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/Business.cs`

Add:
```csharp
public static Business Create(
    string name, string slug, BusinessType businessType,
    Guid ownerId, Location location, string? description = null,
    Guid? placeId = null, string? address = null, string? city = null,
    string? country = null, string? postalCode = null, string? phone = null,
    string? email = null, string? website = null,
    string? licenseNumber = null, string? taxId = null,
    string? metaTitle = null, string? metaDescription = null)
// → Status = BusinessStatus.Pending, IsVerified = false, IsFeatured = false
// → Guid.CreateVersion7()
// → raise BusinessCreatedDomainEvent

public void Update(string name, string slug, BusinessType businessType,
    Location location, string? description, Guid? placeId,
    string? address, string? city, string? country, string? postalCode,
    string? phone, string? email, string? website,
    string? licenseNumber, string? taxId,
    string? metaTitle, string? metaDescription)
// → MarkUpdated(), raise BusinessUpdatedDomainEvent

public void SoftDelete()
// → IsDeleted = true, DeletedAt = DateTime.UtcNow, MarkUpdated()

public Result Approve(Guid reviewedByUserId)
// → guard: Status == Pending
// → Status = Approved, ReviewedByUserId = reviewedByUserId, ReviewedAt = DateTime.UtcNow
// → MarkUpdated(), raise BusinessApprovedDomainEvent

public Result Reject(Guid reviewedByUserId, string reason)
// → guard: Status == Pending
// → Status = Rejected, RejectionReason = reason, ReviewedByUserId, ReviewedAt
// → MarkUpdated(), raise BusinessRejectedDomainEvent

public Result Resubmit()
// → guard: Status == Rejected
// → Status = Pending, RejectionReason = null
// → MarkUpdated()

public Result Suspend(string reason)
// → guard: Status == Approved
// → Status = Suspended, RejectionReason = reason
// → MarkUpdated()

public Result Reinstate()
// → guard: Status == Suspended
// → Status = Approved, RejectionReason = null
// → MarkUpdated()

public void SetVerified(bool isVerified)
// → IsVerified = isVerified, MarkUpdated()

public void SetFeatured(bool isFeatured)
// → IsFeatured = isFeatured, MarkUpdated()

public void UpdateRating(decimal averageRating, int reviewCount)
// → AverageRating = averageRating, ReviewCount = reviewCount, MarkUpdated()
```

### Domain Events

Create `ContentPlaces.Domain/Events/`:
- `BusinessCreatedDomainEvent.cs` — `record(Guid BusinessId, string Name, string Slug, Guid? PlaceId)`
- `BusinessUpdatedDomainEvent.cs` — `record(Guid BusinessId, string Name, string? Description, string? Address)`
- `BusinessApprovedDomainEvent.cs` — `record(Guid BusinessId, Guid ReviewedByUserId)`
- `BusinessRejectedDomainEvent.cs` — `record(Guid BusinessId, string Reason)`

### Repository Interface

Create `ContentPlaces.Domain/Repositories/IBusinessRepository.cs`:

```csharp
public interface IBusinessRepository : IRepository<Business>
{
    Task<bool> ExistsBySlugAsync(string slug, CancellationToken ct = default);
    Task<bool> ExistsBySlugExcludingAsync(string slug, Guid excludeId, CancellationToken ct = default);
    Task<Business?> GetByIdWithTranslationsAsync(Guid id, CancellationToken ct = default);
    Task<List<Business>> GetByPlaceIdAsync(Guid placeId, bool approvedOnly, int page, int pageSize, CancellationToken ct = default);
    Task<int> CountByPlaceIdAsync(Guid placeId, bool approvedOnly, CancellationToken ct = default);
    Task<List<Business>> GetAllForTranslationAsync(CancellationToken ct = default);
}
```

### Application Layer

**Commands** (`ContentPlaces.Application/Commands/Business/`):

| Folder | Notes |
|---|---|
| `CreateBusiness/` | Verify PlaceId exists and not deleted (query IPlaceRepository). Insert `PlaceBusiness` junction row in same `SaveChangesAsync`. Auto-create 7 default `BusinessHours` rows: all days `IsClosed = true`. Trigger translation for Business. |
| `UpdateBusiness/` | IDOR: `OwnerId == currentUserId \|\| isAdmin`. If PlaceId changed: delete old `PlaceBusiness` row, insert new one. Trigger translation if name/description/address changed. |
| `DeleteBusiness/` | Admin only. Soft delete. |
| `ApproveBusiness/` | Admin only. Calls `Business.Approve()`. |
| `RejectBusiness/` | Admin only. Requires `Reason` string. Calls `Business.Reject(reason)`. |
| `ResubmitBusiness/` | Owner only. Calls `Business.Resubmit()`. |
| `SuspendBusiness/` | Admin only. Requires `Reason` string. Calls `Business.Suspend(reason)`. |
| `ReinstateBusiness/` | Admin only. Calls `Business.Reinstate()`. |

**Queries** (`ContentPlaces.Application/Queries/Business/`):

| Folder | DTO | Notes |
|---|---|---|
| `ListPlaceBusinesses/` | `BusinessSummaryDto` | Public returns `Status = Approved` only. Admin/Owner sees all statuses. Pagination max 50. |
| `GetBusinessById/` | `BusinessDetailDto` | All fields + Translations + BusinessHours count + Staff count + ServiceItems count + Amenities |

**DTOs**:

```csharp
public record BusinessSummaryDto(
    Guid Id, string Name, string Slug, string BusinessType, string Status,
    double Lat, double Lng, string? City, string? Country,
    decimal AverageRating, int ReviewCount,
    bool IsVerified, bool IsFeatured, string? PrimaryImageUrl);

public record BusinessDetailDto(
    Guid Id, string Name, string Slug, string BusinessType, string Status,
    string? RejectionReason, double Lat, double Lng,
    string? Address, string? City, string? Country, string? PostalCode,
    string? Phone, string? Email, string? Website, string? Description,
    decimal AverageRating, int ReviewCount,
    bool IsVerified, bool IsFeatured,
    string? LicenseNumber, string? TaxId,
    string? MetaTitle, string? MetaDescription,
    Guid OwnerId, Guid? PlaceId, string? SubscriptionTier,
    int ServiceItemCount, int StaffCount, int AmenityCount,
    IReadOnlyList<BusinessTranslationDto> Translations,
    IReadOnlyList<BusinessHoursSummaryDto> BusinessHours,
    DateTime CreatedAt, DateTime? UpdatedAt);
```

### Infrastructure

- `ContentPlaces.Infrastructure/Repositories/BusinessRepository.cs`
- Register: `services.AddScoped<IBusinessRepository, BusinessRepository>();`
- `PlaceBusiness` junction managed directly via `ContentPlacesDbContext` in handlers — no separate repository

### Presentation (9 endpoints)

```
GET    /api/places/{id:guid}/businesses              →  ListPlaceBusinesses   .AllowAnonymous()
GET    /api/places/businesses/{id:guid}              →  GetBusinessById       .AllowAnonymous()
POST   /api/places/businesses                        →  CreateBusiness        .RequireAuthorization()
PUT    /api/places/businesses/{id:guid}              →  UpdateBusiness        .RequireAuthorization()
DELETE /api/places/businesses/{id:guid}              →  DeleteBusiness        .RequireAuthorization("Admin")
POST   /api/places/businesses/{id:guid}/resubmit     →  ResubmitBusiness      .RequireAuthorization()
POST   /api/places/businesses/admin/{id:guid}/approve   →  ApproveBusiness    .RequireAuthorization("Admin")
POST   /api/places/businesses/admin/{id:guid}/reject    →  RejectBusiness     .RequireAuthorization("Admin")
POST   /api/places/businesses/admin/{id:guid}/suspend   →  SuspendBusiness    .RequireAuthorization("Admin")
```

---

## Task 3 — BusinessHours Batch Upsert

**Phase**: 1 — MVP
**Endpoints**: 2
**Depends on**: Task 2 (BusinessId must exist)

### Schema Notes

- `BusinessHours` is `BaseEntity` — has `Id`, `CreatedAt`, `UpdatedAt` but **no** `IsDeleted`, no `RowVersion`
- Query filter goes through `!x.Business.IsDeleted` — already in EF config
- Unique index removed (see Schema Conflict Resolution) — now allows multiple rows per (BusinessId, DayOfWeek)
- **Max 2 entries per day** enforced at application layer
- **Split-shift rules**: for the same day, entries must not overlap; `entry[n].OpenTime >= entry[n-1].CloseTime`

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/BusinessHours.cs`

```csharp
public static BusinessHours Create(
    Guid businessId, DayOfWeek dayOfWeek,
    TimeOnly openTime, TimeOnly closeTime, bool isClosed)
{
    if (businessId == Guid.Empty)
        throw new ArgumentException("BusinessId is required.", nameof(businessId));
    if (!isClosed && openTime >= closeTime)
        throw new ArgumentException("OpenTime must be before CloseTime.", nameof(openTime));

    return new BusinessHours
    {
        Id = Guid.CreateVersion7(),
        BusinessId = businessId,
        DayOfWeek = dayOfWeek,
        OpenTime = openTime,
        CloseTime = closeTime,
        IsClosed = isClosed
    };
}

public void Update(TimeOnly openTime, TimeOnly closeTime, bool isClosed)
{
    if (!isClosed && openTime >= closeTime)
        throw new ArgumentException("OpenTime must be before CloseTime.");
    OpenTime = openTime;
    CloseTime = closeTime;
    IsClosed = isClosed;
    UpdatedAt = DateTime.UtcNow;
}
```

### Application Layer

**Queries** (`ContentPlaces.Application/Queries/BusinessHours/`):
- `GetBusinessHoursQuery(Guid BusinessId)` — returns `List<BusinessHoursDto>` for all rows; no authentication required

**Commands** (`ContentPlaces.Application/Commands/BusinessHours/`):
- `SetBusinessHoursCommand(Guid BusinessId, IReadOnlyList<BusinessHourItem> Hours)` — batch replace strategy

**DTOs**:
```csharp
public record BusinessHoursDto(
    Guid Id, string DayOfWeek,
    string OpenTime, string CloseTime, bool IsClosed);

public record BusinessHourItem(
    string DayOfWeek, string OpenTime, string CloseTime, bool IsClosed);
```

**Validator Rules** (`SetBusinessHoursCommandValidator`):
- `BusinessId`: `.NotEqual(Guid.Empty)`
- `Hours`: `.NotEmpty()`
- Per item: `OpenTime` and `CloseTime` must be valid `TimeOnly` strings (`HH:mm`)
- Per item: if `!IsClosed`, `OpenTime < CloseTime` (unless 24h: both `00:00`)
- Per day: max 2 entries
- Per day with 2 entries: entries must not overlap — `entry2.OpenTime >= entry1.CloseTime`

**Handler logic** (`SetBusinessHoursCommandHandler`):
1. Verify `BusinessId` exists and is not deleted (via `ContentPlacesDbContext` — no repo needed)
2. IDOR: verify `business.OwnerId == currentUserId || isAdmin`
3. Delete all existing `BusinessHours` rows for `BusinessId`: `dbContext.BusinessHours.Where(x => x.BusinessId == request.BusinessId).ExecuteDeleteAsync(ct)` (EF raw delete, bypasses query filter — use `IgnoreQueryFilters()`)
4. Create new rows using `BusinessHours.Create(...)`
5. `dbContext.BusinessHours.AddRangeAsync(newRows, ct)`
6. `await unitOfWork.SaveChangesAsync(ct)`

### Presentation (2 endpoints)

```
GET  /api/places/businesses/{id:guid}/hours  →  GetBusinessHours  .AllowAnonymous()
PUT  /api/places/businesses/{id:guid}/hours  →  SetBusinessHours  .RequireAuthorization()
```

---

## Task 4 — ServiceItem Full CQRS

**Phase**: 1 — MVP
**Endpoints**: 5
**Depends on**: Task 2 (BusinessId must exist)

### Entity Notes

- `ServiceItem` is `AuditableEntity` (non-aggregate) — has `IsDeleted`, `DeletedAt`, `RowVersion`
- Query filter: `HasQueryFilter(x => !x.IsDeleted)` — already configured
- Use `EfEntityRepository<ServiceItem, Guid>` in infrastructure

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/ServiceItem.cs`

```csharp
public static ServiceItem Create(
    Guid businessId, string name, ServiceCategory category,
    decimal price, string currency, int durationMinutes,
    int maxCapacity, int sortOrder, string? description = null)
{
    if (businessId == Guid.Empty) throw new ArgumentException(...);
    ArgumentException.ThrowIfNullOrWhiteSpace(name);
    if (price < 0) throw new ArgumentException("Price cannot be negative.");
    if (durationMinutes <= 0) throw new ArgumentException("Duration must be positive.");
    if (maxCapacity <= 0) throw new ArgumentException("Capacity must be positive.");

    return new ServiceItem
    {
        Id = Guid.CreateVersion7(),
        BusinessId = businessId,
        Name = name.Trim(),
        Description = description?.Trim(),
        Category = category,
        Price = price,
        PriceCurrency = currency.ToUpperInvariant(),
        Currency = currency.ToUpperInvariant(),
        DurationMinutes = durationMinutes,
        MaxCapacity = maxCapacity,
        SortOrder = sortOrder,
        IsAvailable = true
    };
}

public void Update(string name, ServiceCategory category, decimal price,
    string currency, int durationMinutes, int maxCapacity,
    int sortOrder, string? description)
// → update fields, UpdatedAt = DateTime.UtcNow

public void SetAvailability(bool isAvailable)
// → IsAvailable = isAvailable, UpdatedAt = DateTime.UtcNow

public void ApplyDiscount(decimal discountPercent, decimal salePrice,
    string salePriceCurrency, DateTime validFrom, DateTime validTo)
// → set all discount fields, UpdatedAt

public void RemoveDiscount()
// → set all discount fields to null, UpdatedAt

public void SoftDelete()
// → IsDeleted = true, DeletedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
```

### Repository Interface

Create `ContentPlaces.Domain/Repositories/IServiceItemRepository.cs`:
```csharp
public interface IServiceItemRepository
    : IReadRepository<ServiceItem, Guid>, IWriteRepository<ServiceItem, Guid>
{
    Task<List<ServiceItem>> GetByBusinessIdAsync(
        Guid businessId, bool includeUnavailable,
        CancellationToken ct = default);
}
```

### Application Layer

**Commands** (`ContentPlaces.Application/Commands/ServiceItem/`):

| Folder | Notes |
|---|---|
| `CreateServiceItem/` | IDOR: verify `business.OwnerId == currentUserId \|\| isAdmin`; verify BusinessId exists |
| `UpdateServiceItem/` | IDOR check |
| `DeleteServiceItem/` | IDOR check; soft delete |
| `SetServiceItemAvailability/` | `PATCH`; IDOR check |

**Queries** (`ContentPlaces.Application/Queries/ServiceItem/`):

| Folder | DTO | Notes |
|---|---|---|
| `ListServiceItems/` | `ServiceItemSummaryDto` | Public → `IsAvailable = true` only. Owner/Admin → all. Sorted by `SortOrder`. |
| `GetServiceItemById/` | `ServiceItemDetailDto` | All fields including discount info |

**DTOs**:
```csharp
public record ServiceItemSummaryDto(
    Guid Id, string Name, string Category,
    decimal Price, string Currency,
    int DurationMinutes, int MaxCapacity,
    bool IsAvailable, int SortOrder,
    decimal? SalePrice, string? SalePriceCurrency);

public record ServiceItemDetailDto(
    Guid Id, Guid BusinessId, string Name, string? Description, string Category,
    decimal Price, string Currency,
    int DurationMinutes, int MaxCapacity,
    bool IsAvailable, int SortOrder,
    decimal? DiscountPercent, decimal? SalePrice, string? SalePriceCurrency,
    DateTime? DiscountValidFrom, DateTime? DiscountValidTo,
    DateTime CreatedAt, DateTime? UpdatedAt);
```

### Infrastructure

- `ContentPlaces.Infrastructure/Repositories/ServiceItemRepository.cs` — extends `EfEntityRepository<ServiceItem, Guid>`
- Register: `services.AddScoped<IServiceItemRepository, ServiceItemRepository>();`

### Presentation (5 endpoints)

```
GET    /api/places/businesses/{id:guid}/services           →  ListServiceItems         .AllowAnonymous()
GET    /api/places/businesses/services/{id:guid}           →  GetServiceItemById       .AllowAnonymous()
POST   /api/places/businesses/{id:guid}/services           →  CreateServiceItem        .RequireAuthorization()
PUT    /api/places/businesses/services/{id:guid}           →  UpdateServiceItem        .RequireAuthorization()
DELETE /api/places/businesses/services/{id:guid}           →  DeleteServiceItem        .RequireAuthorization()
```

> `PATCH /api/places/businesses/services/{id:guid}/availability` can be added as a convenience endpoint (optional, 6th endpoint).

---

## Task 5 — BusinessAmenity Management

**Phase**: 1 — MVP
**Endpoints**: 3
**Depends on**: Task 2 (BusinessId must exist)

### Entity Notes

- `BusinessAmenity` is `BaseEntity` (non-aggregate) — **no** `IsDeleted`, **no** `RowVersion`
- Query filter goes through `!x.Business.IsDeleted` — already in EF config
- **Hard delete** on remove — use `dbContext.BusinessAmenities.Remove(amenity)`
- Managed via `ContentPlacesDbContext` directly — no separate repository

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/BusinessAmenity.cs`

```csharp
public static BusinessAmenity Create(
    Guid businessId, string name, int sortOrder, string? icon = null)
{
    if (businessId == Guid.Empty) throw new ArgumentException(...);
    ArgumentException.ThrowIfNullOrWhiteSpace(name);

    return new BusinessAmenity
    {
        Id = Guid.CreateVersion7(),
        BusinessId = businessId,
        Name = name.Trim(),
        Icon = icon?.Trim(),
        SortOrder = sortOrder
    };
}

public void Update(string name, int sortOrder, string? icon)
{
    ArgumentException.ThrowIfNullOrWhiteSpace(name);
    Name = name.Trim();
    Icon = icon?.Trim();
    SortOrder = sortOrder;
    UpdatedAt = DateTime.UtcNow;
}
```

### Application Layer

**Commands** (`ContentPlaces.Application/Commands/BusinessAmenity/`):

| Folder | Notes |
|---|---|
| `AddBusinessAmenity/` | IDOR: owner or admin; verify BusinessId exists |
| `UpdateBusinessAmenity/` | IDOR check |
| `RemoveBusinessAmenity/` | IDOR check; hard delete via `dbContext.BusinessAmenities.Remove()` |

**Queries** (`ContentPlaces.Application/Queries/BusinessAmenity/`):
- `ListBusinessAmenities(Guid BusinessId)` — public; sorted by `SortOrder`

**DTO**:
```csharp
public record BusinessAmenityDto(Guid Id, string Name, string? Icon, int SortOrder);
```

### Presentation (3 endpoints)

```
GET    /api/places/businesses/{id:guid}/amenities        →  ListBusinessAmenities  .AllowAnonymous()
POST   /api/places/businesses/{id:guid}/amenities        →  AddBusinessAmenity     .RequireAuthorization()
DELETE /api/places/businesses/amenities/{id:guid}        →  RemoveBusinessAmenity  .RequireAuthorization()
```

---

## Task 6 — BusinessStaff Management

**Phase**: 1 — MVP
**Endpoints**: 3
**Depends on**: Task 2 (BusinessId must exist)

### Entity Notes

- `BusinessStaff` is `AuditableEntity` (non-aggregate) — has `IsDeleted`, `RowVersion`
- Unique index on `(BusinessId, UserId)` filtered where `IsDeleted = 0` — already in EF config
- Staff list is **not public** — owner or admin only

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/BusinessStaff.cs`

```csharp
public static BusinessStaff Create(
    Guid businessId, Guid userId, BusinessStaffRole role,
    Guid? joinRequestId = null)
{
    if (businessId == Guid.Empty) throw new ArgumentException(...);
    if (userId == Guid.Empty) throw new ArgumentException(...);

    return new BusinessStaff
    {
        Id = Guid.CreateVersion7(),
        BusinessId = businessId,
        UserId = userId,
        Role = role,
        JoinRequestId = joinRequestId,
        IsActive = true
    };
}

public void Deactivate()
{
    IsActive = false;
    DeactivatedAt = DateTime.UtcNow;
    MarkUpdated();
}

public void SoftDelete()
{
    IsDeleted = true;
    DeletedAt = DateTime.UtcNow;
    MarkUpdated();
}
```

### Application Layer

**Commands** (`ContentPlaces.Application/Commands/BusinessStaff/`):

| Folder | Notes |
|---|---|
| `AddBusinessStaff/` | Owner or admin only; verify UserId not already active staff on this business (check unique index — query `dbContext.BusinessStaff.AnyAsync(x => x.BusinessId == id && x.UserId == userId && !x.IsDeleted)`); verify BusinessId exists |
| `RemoveBusinessStaff/` | Owner or admin only; calls `SoftDelete()` |

**Queries**:
- `ListBusinessStaff(Guid BusinessId)` — owner or admin only; sorted by `Role`, then `CreatedAt`

**DTO**:
```csharp
public record BusinessStaffDto(
    Guid Id, Guid UserId, string Role,
    bool IsActive, DateTime? DeactivatedAt, DateTime CreatedAt);
```

### Presentation (3 endpoints)

```
GET    /api/places/businesses/{id:guid}/staff         →  ListBusinessStaff   .RequireAuthorization()
POST   /api/places/businesses/{id:guid}/staff         →  AddBusinessStaff    .RequireAuthorization()
DELETE /api/places/businesses/staff/{id:guid}         →  RemoveBusinessStaff .RequireAuthorization()
```

---

## Task 7 — Place Geo-Search

**Phase**: 2 — Discovery
**Endpoints**: 2
**Depends on**: Task 1 (Places table must be populated)

### Application Layer Only — No Domain Changes

**Queries** (`ContentPlaces.Application/Queries/Place/`):

`GetNearbyPlacesQuery`:
- Inputs: `Lat (double)`, `Lng (double)`, `RadiusKm (double, max 100)`, `Page (int)`, `PageSize (int, max 50)`
- SQL Haversine formula (raw SQL via `dbContext.Places.FromSqlRaw(...)` or `FromSqlInterpolated`):
  ```sql
  SELECT *, (6371 * 2 * ASIN(SQRT(
      POWER(SIN(RADIANS({lat} - Latitude) / 2), 2) +
      COS(RADIANS(Latitude)) * COS(RADIANS({lat})) *
      POWER(SIN(RADIANS({lng} - Longitude) / 2), 2)
  ))) AS DistanceKm
  FROM content_places.Places
  WHERE IsDeleted = 0
    AND (6371 * 2 * ASIN(SQRT(...))) <= {radiusKm}
  ORDER BY DistanceKm ASC
  ```
- Returns `NearbyPlaceSummaryDto` with `DistanceKm` field added

`GetMapViewportQuery`:
- Inputs: `NorthLat`, `SouthLat`, `EastLng`, `WestLng` (all doubles)
- Simple bounding box LINQ: `Where(p => p.Location.Latitude <= northLat && p.Location.Latitude >= southLat && p.Location.Longitude <= eastLng && p.Location.Longitude >= westLng && !p.IsDeleted)`
- Returns `MapPinDto` — minimal payload for map pins
- Sets `IsClusteringRecommended = count > 50` in response

**DTOs**:
```csharp
public record NearbyPlaceSummaryDto(
    Guid Id, string Name, string Slug, double Lat, double Lng,
    decimal AverageRating, string? PrimaryImageUrl,
    double DistanceKm);

public record MapViewportResponse(
    IReadOnlyList<MapPinDto> Pins, bool IsClusteringRecommended);

public record MapPinDto(
    Guid Id, string Name, double Lat, double Lng,
    string? PrimaryImageUrl, decimal AverageRating, int TourCount);
```

**Validator Rules**:
- `GetNearbyPlacesQuery`: `Lat` in `[-90, 90]`, `Lng` in `[-180, 180]`, `RadiusKm` in `(0, 100]`, `PageSize` in `[1, 50]`
- `GetMapViewportQuery`: `NorthLat > SouthLat`, `EastLng > WestLng`, all in valid ranges

### Presentation (2 endpoints)

```
GET  /api/places/nearby         →  GetNearbyPlaces   .AllowAnonymous()
GET  /api/places/map/viewport   →  GetMapViewport    .AllowAnonymous()
```

---

## Task 8 — AccessibilityFeature

**Phase**: 3 — Growth
**Endpoints**: 2
**Depends on**: Task 1 (PlaceId must exist)

### Entity Notes

- `AccessibilityFeature` is `BaseEntity` — **no** `IsDeleted`, **no** `RowVersion`
- No query filter in EF config (no soft-delete)
- **Hard-replace strategy**: delete all existing rows for `(EntityType, EntityId)`, insert new set
- Polymorphic: `EntityType (byte)` + `EntityId (Guid)` — for Phase 3, only `EntityType = Place` is used from this module's endpoints
- No separate repository — use `ContentPlacesDbContext` directly

### Domain Changes Required

File: `ContentPlaces.Domain/Entities/AccessibilityFeature.cs`

```csharp
public static AccessibilityFeature Create(
    byte entityType, Guid entityId,
    AccessibilityFeatureType featureType, string name,
    bool isAvailable, string? description = null)
{
    if (entityId == Guid.Empty) throw new ArgumentException(...);
    ArgumentException.ThrowIfNullOrWhiteSpace(name);

    return new AccessibilityFeature
    {
        Id = Guid.CreateVersion7(),
        EntityType = entityType,
        EntityId = entityId,
        FeatureType = featureType,
        Name = name.Trim(),
        Description = description?.Trim(),
        IsAvailable = isAvailable
    };
}

public void Update(string name, bool isAvailable, string? description)
{
    ArgumentException.ThrowIfNullOrWhiteSpace(name);
    Name = name.Trim();
    Description = description?.Trim();
    IsAvailable = isAvailable;
    UpdatedAt = DateTime.UtcNow;
}
```

### Application Layer

**Queries** (`ContentPlaces.Application/Queries/AccessibilityFeature/`):
- `GetAccessibilityFeaturesQuery(byte EntityType, Guid EntityId)` — public; returns all rows grouped by `FeatureType`

**Commands** (`ContentPlaces.Application/Commands/AccessibilityFeature/`):
- `UpdateAccessibilityFeaturesCommand(Guid PlaceId, IReadOnlyList<AccessibilityFeatureItem> Features)` — admin only
  1. Verify PlaceId exists
  2. Hard-delete existing: `await dbContext.AccessibilityFeatures.Where(x => x.EntityType == placeEntityType && x.EntityId == request.PlaceId).ExecuteDeleteAsync(ct)`
  3. Create new rows, bulk insert
  4. `await unitOfWork.SaveChangesAsync(ct)`

**DTOs**:
```csharp
public record AccessibilityFeatureDto(
    Guid Id, string FeatureType, string Name,
    string? Description, bool IsAvailable);

public record AccessibilityFeatureItem(
    string FeatureType, string Name, bool IsAvailable, string? Description);
```

### Presentation (2 endpoints)

```
GET  /api/places/{id:guid}/accessibility  →  GetAccessibilityFeatures     .AllowAnonymous()
PUT  /api/places/{id:guid}/accessibility  →  UpdateAccessibilityFeatures  .RequireAuthorization("Admin")
```

---

## WBS Plan

```
ContentPlaces Module
│
├── 0. Pre-work (DONE ✅)
│   ├── 0.1 Resolve BusinessHours schema conflict
│   │   ├── Remove unique index (BusinessId, DayOfWeek) from EF config       ✅
│   │   ├── Add design-time factory (ContentPlacesDbContextFactory)           ✅
│   │   └── Migration: UpdateBusinessHoursAllowSplitShifts                    ✅
│   └── 0.2 Fix pre-existing ContentCore build errors                         ✅
│       ├── Restore ReorderCategoriesCommand.cs                               ✅
│       └── Restore ReorderCategoriesCommandHandler.cs                        ✅
│
├── 1. Place CQRS + Admin Actions                         [8 endpoints, Phase 1]
│   ├── 1.1 Domain
│   │   ├── Place.Create() factory method
│   │   ├── Place.Update() business method
│   │   ├── Place.SoftDelete()
│   │   ├── Place.SetFeatured(), Place.SetVerified()
│   │   ├── Place.UpdateRating()
│   │   ├── PlaceCreatedDomainEvent
│   │   ├── PlaceUpdatedDomainEvent
│   │   └── IPlaceRepository interface
│   ├── 1.2 Application — Commands
│   │   ├── CreatePlaceCommand + Handler + Validator
│   │   ├── UpdatePlaceCommand + Handler + Validator
│   │   ├── DeletePlaceCommand + Handler
│   │   ├── FeaturePlaceCommand + Handler
│   │   └── VerifyPlaceCommand + Handler
│   ├── 1.3 Application — Queries + DTOs
│   │   ├── ListPlacesQuery + Handler + PlaceSummaryDto
│   │   ├── GetPlaceByIdQuery + Handler + PlaceDetailDto
│   │   └── GetPlaceBySlugQuery + Handler
│   ├── 1.4 Infrastructure
│   │   ├── PlaceRepository
│   │   └── DI registration
│   ├── 1.5 Contracts
│   │   └── PlaceCreatedIntegrationEvent
│   └── 1.6 Presentation
│       └── 8 endpoints in ContentPlacesEndpoints.cs
│
├── 2. Business CQRS + State Machine                      [9 endpoints, Phase 1]
│   ├── 2.1 Domain
│   │   ├── Business.Create() factory
│   │   ├── Business.Update()
│   │   ├── Business.SoftDelete()
│   │   ├── Business.Approve(), Reject(), Resubmit()
│   │   ├── Business.Suspend(), Reinstate()
│   │   ├── Business.SetVerified(), SetFeatured()
│   │   ├── Business.UpdateRating()
│   │   ├── BusinessCreatedDomainEvent
│   │   ├── BusinessUpdatedDomainEvent
│   │   ├── BusinessApprovedDomainEvent
│   │   ├── BusinessRejectedDomainEvent
│   │   └── IBusinessRepository interface
│   ├── 2.2 Application — Commands
│   │   ├── CreateBusinessCommand + Handler + Validator
│   │   │   └── (auto-creates 7 default BusinessHours rows)
│   │   ├── UpdateBusinessCommand + Handler + Validator
│   │   ├── DeleteBusinessCommand + Handler
│   │   ├── ApproveBusinessCommand + Handler
│   │   ├── RejectBusinessCommand + Handler + Validator
│   │   ├── ResubmitBusinessCommand + Handler
│   │   ├── SuspendBusinessCommand + Handler + Validator
│   │   └── ReinstateBusinessCommand + Handler
│   ├── 2.3 Application — Queries + DTOs
│   │   ├── ListPlaceBusinessesQuery + Handler + BusinessSummaryDto
│   │   └── GetBusinessByIdQuery + Handler + BusinessDetailDto
│   ├── 2.4 Infrastructure
│   │   ├── BusinessRepository
│   │   └── DI registration
│   └── 2.5 Presentation
│       └── 9 endpoints in ContentPlacesEndpoints.cs
│
├── 3. BusinessHours Batch Upsert                         [2 endpoints, Phase 1]
│   ├── 3.1 Domain
│   │   ├── BusinessHours.Create() factory
│   │   └── BusinessHours.Update()
│   ├── 3.2 Application
│   │   ├── GetBusinessHoursQuery + Handler + BusinessHoursDto
│   │   └── SetBusinessHoursCommand + Handler + Validator
│   │       └── (overlap validation + split-shift logic)
│   └── 3.3 Presentation
│       └── 2 endpoints in ContentPlacesEndpoints.cs
│
├── 4. ServiceItem Full CQRS                              [5 endpoints, Phase 1]
│   ├── 4.1 Domain
│   │   ├── ServiceItem.Create() factory
│   │   ├── ServiceItem.Update()
│   │   ├── ServiceItem.SetAvailability()
│   │   ├── ServiceItem.ApplyDiscount(), RemoveDiscount()
│   │   ├── ServiceItem.SoftDelete()
│   │   └── IServiceItemRepository interface
│   ├── 4.2 Application — Commands
│   │   ├── CreateServiceItemCommand + Handler + Validator
│   │   ├── UpdateServiceItemCommand + Handler + Validator
│   │   ├── DeleteServiceItemCommand + Handler
│   │   └── SetServiceItemAvailabilityCommand + Handler
│   ├── 4.3 Application — Queries + DTOs
│   │   ├── ListServiceItemsQuery + Handler + ServiceItemSummaryDto
│   │   └── GetServiceItemByIdQuery + Handler + ServiceItemDetailDto
│   ├── 4.4 Infrastructure
│   │   ├── ServiceItemRepository (EfEntityRepository)
│   │   └── DI registration
│   └── 4.5 Presentation
│       └── 5 endpoints in ContentPlacesEndpoints.cs
│
├── 5. BusinessAmenity Management                         [3 endpoints, Phase 1]
│   ├── 5.1 Domain
│   │   ├── BusinessAmenity.Create() factory
│   │   └── BusinessAmenity.Update()
│   ├── 5.2 Application
│   │   ├── ListBusinessAmenitiesQuery + Handler + BusinessAmenityDto
│   │   ├── AddBusinessAmenityCommand + Handler + Validator
│   │   ├── UpdateBusinessAmenityCommand + Handler + Validator
│   │   └── RemoveBusinessAmenityCommand + Handler
│   └── 5.3 Presentation
│       └── 3 endpoints in ContentPlacesEndpoints.cs
│
├── 6. BusinessStaff Management                           [3 endpoints, Phase 1]
│   ├── 6.1 Domain
│   │   ├── BusinessStaff.Create() factory
│   │   ├── BusinessStaff.Deactivate()
│   │   └── BusinessStaff.SoftDelete()
│   ├── 6.2 Application
│   │   ├── ListBusinessStaffQuery + Handler + BusinessStaffDto
│   │   ├── AddBusinessStaffCommand + Handler + Validator
│   │   └── RemoveBusinessStaffCommand + Handler
│   └── 6.3 Presentation
│       └── 3 endpoints in ContentPlacesEndpoints.cs
│
├── 7. Place Geo-Search                                   [2 endpoints, Phase 2]
│   ├── 7.1 Application
│   │   ├── GetNearbyPlacesQuery + Handler + NearbyPlaceSummaryDto
│   │   └── GetMapViewportQuery + Handler + MapPinDto
│   └── 7.2 Presentation
│       └── 2 endpoints in ContentPlacesEndpoints.cs
│
└── 8. AccessibilityFeature                               [2 endpoints, Phase 3]
    ├── 8.1 Domain
    │   ├── AccessibilityFeature.Create() factory
    │   └── AccessibilityFeature.Update()
    ├── 8.2 Application
    │   ├── GetAccessibilityFeaturesQuery + Handler + AccessibilityFeatureDto
    │   └── UpdateAccessibilityFeaturesCommand + Handler + Validator
    └── 8.3 Presentation
        └── 2 endpoints in ContentPlacesEndpoints.cs
```

---

## Endpoint Summary

| # | Method | Route | Auth | Task | Phase |
|---|--------|-------|------|------|-------|
| 1 | GET | `/api/places` | Anonymous | 1 | 1 |
| 2 | GET | `/api/places/{id}` | Anonymous | 1 | 1 |
| 3 | GET | `/api/places/{slug}` | Anonymous | 1 | 1 |
| 4 | POST | `/api/places` | Admin | 1 | 1 |
| 5 | PUT | `/api/places/{id}` | Admin | 1 | 1 |
| 6 | DELETE | `/api/places/{id}` | Admin | 1 | 1 |
| 7 | PATCH | `/api/places/{id}/feature` | Admin | 1 | 1 |
| 8 | PATCH | `/api/places/{id}/verify` | Admin | 1 | 1 |
| 9 | GET | `/api/places/{id}/businesses` | Anonymous | 2 | 1 |
| 10 | GET | `/api/places/businesses/{id}` | Anonymous | 2 | 1 |
| 11 | POST | `/api/places/businesses` | Authenticated | 2 | 1 |
| 12 | PUT | `/api/places/businesses/{id}` | Authenticated | 2 | 1 |
| 13 | DELETE | `/api/places/businesses/{id}` | Admin | 2 | 1 |
| 14 | POST | `/api/places/businesses/{id}/resubmit` | Authenticated | 2 | 1 |
| 15 | POST | `/api/places/businesses/admin/{id}/approve` | Admin | 2 | 1 |
| 16 | POST | `/api/places/businesses/admin/{id}/reject` | Admin | 2 | 1 |
| 17 | POST | `/api/places/businesses/admin/{id}/suspend` | Admin | 2 | 1 |
| 18 | GET | `/api/places/businesses/{id}/hours` | Anonymous | 3 | 1 |
| 19 | PUT | `/api/places/businesses/{id}/hours` | Authenticated | 3 | 1 |
| 20 | GET | `/api/places/businesses/{id}/services` | Anonymous | 4 | 1 |
| 21 | GET | `/api/places/businesses/services/{id}` | Anonymous | 4 | 1 |
| 22 | POST | `/api/places/businesses/{id}/services` | Authenticated | 4 | 1 |
| 23 | PUT | `/api/places/businesses/services/{id}` | Authenticated | 4 | 1 |
| 24 | DELETE | `/api/places/businesses/services/{id}` | Authenticated | 4 | 1 |
| 25 | GET | `/api/places/businesses/{id}/amenities` | Anonymous | 5 | 1 |
| 26 | POST | `/api/places/businesses/{id}/amenities` | Authenticated | 5 | 1 |
| 27 | DELETE | `/api/places/businesses/amenities/{id}` | Authenticated | 5 | 1 |
| 28 | GET | `/api/places/businesses/{id}/staff` | Authenticated | 6 | 1 |
| 29 | POST | `/api/places/businesses/{id}/staff` | Authenticated | 6 | 1 |
| 30 | DELETE | `/api/places/businesses/staff/{id}` | Authenticated | 6 | 1 |
| 31 | GET | `/api/places/nearby` | Anonymous | 7 | 2 |
| 32 | GET | `/api/places/map/viewport` | Anonymous | 7 | 2 |
| 33 | GET | `/api/places/{id}/accessibility` | Anonymous | 8 | 3 |
| 34 | PUT | `/api/places/{id}/accessibility` | Admin | 8 | 3 |

---

## Critical Rules for This Module

### Always
- Inject `IContentPlacesUnitOfWork` and call `SaveChangesAsync(ct)` — never `dbContext.SaveChangesAsync()` directly in handlers
- Use `Guid.CreateVersion7()` in all factory methods, never `Guid.NewGuid()`
- Use `DateTime.UtcNow` everywhere, never `DateTime.Now`
- Pass `CancellationToken ct` through every async call
- Add `ILogger<THandler>` to every command handler constructor
- Follow `PlaceSummaryDto` / `PlaceDetailDto` naming — never return the entity itself

### IDOR Checks (mandatory on every write endpoint)
- **Place** writes: admin only — check via `[RequireAuthorization("Admin")]` at endpoint level
- **Business** writes: `business.OwnerId == currentUserId || isAdmin` — check in handler
- **ServiceItem / Amenity / Staff / Hours** writes: resolve parent Business, check `business.OwnerId == currentUserId || isAdmin`

### Translation Triggers
- **CreatePlace**: call `IEntityTranslationOrchestrator.TranslateAsync(fields, sourceLanguage, allActiveLangCodes, ct)` after saving
- **UpdatePlace**: trigger re-translation if `Name`, `Description`, or `Address` changed
- **CreateBusiness**: same orchestrator pattern
- **UpdateBusiness**: same trigger rule
- Translation fields for Place: `Name`, `Description`, `Address`
- Translation fields for Business: `Name`, `Description`, `Address`

### Integration Events (outbox)
- `CreatePlaceCommandHandler` → publish `PlaceCreatedIntegrationEvent` via outbox
- Defined in `ContentPlaces.Contracts/IntegrationEvents/`

### BusinessHours Split-Shift Rules
- Max 2 entries per `(BusinessId, DayOfWeek)` pair
- If 2 entries exist for same day: `entry2.OpenTime >= entry1.CloseTime` (no overlap)
- 24-hour indicator: `OpenTime = 00:00, CloseTime = 00:00, IsClosed = false`
- Always validate in `SetBusinessHoursCommandValidator` before handler executes

### PlaceBusiness Junction
- Managed directly via `ContentPlacesDbContext` in Business handlers — no repository
- `CreateBusiness`: if `PlaceId != null` → insert `new PlaceBusiness { PlaceId = placeId, BusinessId = business.Id }`
- `UpdateBusiness`: if `PlaceId` changed → delete old row, insert new row — in same `SaveChangesAsync`

### Hard-Delete Entities
- `BusinessAmenity` — `dbContext.BusinessAmenities.Remove(amenity)`
- `AccessibilityFeature` — `dbContext.AccessibilityFeatures.Where(...).ExecuteDeleteAsync(ct)` (call `IgnoreQueryFilters()` if query filter exists)
- `BusinessHours` (on replace) — `dbContext.Database.ExecuteSqlInterpolated(...)` or `.Where(...).ExecuteDeleteAsync(ct)` with `IgnoreQueryFilters()`
